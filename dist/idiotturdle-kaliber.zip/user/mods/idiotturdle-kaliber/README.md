# **[ T.A.R.K. ] Tactical Arms Racketeer: Kaliber**
## Backstory
**Kaliber - The Tactical Arms Racketeer:**

Born in the war-torn Balkans, Mikhail "Kaliber" Kozlov grew up surrounded by conflict. As a teenager, he learned the value of firepower—not just in battle, but in business. Smuggling ammunition and repairing abandoned weapons, he built a reputation as someone who could find, fix, and flip anything that shot, exploded, or killed.

By his mid-20s, he had contacts in ex-Soviet military stockpiles, European black markets, and Middle Eastern war zones. Governments, rebels, and mercenaries alike knew that if they needed specialized gear—armor-piercing rounds, experimental scopes, vintage suppressors—Kaliber was the man to call. His network stretched from back-alley arms fairs in Serbia to elite private security firms in Paris.

Despite his ruthless efficiency, Kaliber is not just a thug with bullets—he’s a businessman. He deals in weapons, not wars, and only moves product when the price is right. But if you cross him? Well, let’s just say he never sells anything he hasn’t tested himself.

## Mod Details

This mod adds a trader who sells all ammunition types and grenades found in the region of Tarkov.